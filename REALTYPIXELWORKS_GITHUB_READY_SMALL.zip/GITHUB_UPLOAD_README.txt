REALTYPIXELWORKS — GITHUB READY

IMPORTANT:
Do NOT upload this ZIP itself as the website file.

1. Extract this ZIP on your computer.
2. Open the extracted folder.
3. In GitHub > Add file > Upload files, upload the CONTENTS:
   index.html
   services.html
   portfolio.html
   contact.html
   thank-you.html
   assets folder
   manifest.webmanifest
   sw.js
   vercel.json
   and the other included files.
4. Commit changes.
5. Import/connect the GitHub repository in Vercel.

This build has optimized web images so the project is much smaller while keeping good website quality.
