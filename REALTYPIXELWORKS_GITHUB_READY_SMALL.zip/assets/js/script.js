document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.ba').forEach(b=>{const r=b.querySelector('.range'),a=b.querySelector('.after'),l=b.querySelector('.line'),h=b.querySelector('.handle');r.addEventListener('input',e=>{let v=e.target.value;a.style.clipPath=`inset(0 0 0 ${v}%)`;l.style.left=v+'%';h.style.left=v+'%'})})});

// Click / tap to open portfolio, service and floor-plan images
document.addEventListener("DOMContentLoaded",()=>{
  const candidates = document.querySelectorAll(
    ".portfolio img, .item img, .card img, .ba img, .drone-gallery img, .exterior-gallery img, .interior-gallery img"
  );

  candidates.forEach(img=>{
    img.classList.add("zoomable-img");
    img.addEventListener("click", e=>{
      // Do not trigger preview while interacting with before/after slider
      if(img.closest(".ba") && e.target.closest(".ba")?.querySelector(".range") === e.target) return;

      let modal = document.querySelector(".img-lightbox");
      if(!modal){
        modal = document.createElement("div");
        modal.className = "img-lightbox";
        modal.innerHTML = `
          <button class="img-lightbox-close" aria-label="Close image">×</button>
          <img alt="">
          <div class="img-lightbox-caption"></div>
        `;
        document.body.appendChild(modal);

        const close = ()=>modal.classList.remove("open");
        modal.querySelector(".img-lightbox-close").addEventListener("click", close);
        modal.addEventListener("click", ev=>{ if(ev.target === modal) close(); });
        document.addEventListener("keydown", ev=>{ if(ev.key === "Escape") close(); });
      }

      const modalImg = modal.querySelector("img");
      const caption = modal.querySelector(".img-lightbox-caption");
      modalImg.src = img.src;
      modalImg.alt = img.alt || "";
      const fig = img.closest("figure");
      caption.textContent = fig?.innerText?.trim() || img.alt || "";
      modal.classList.add("open");
    });
  });
});






// Interactive full-screen modal for ALL Before/After sliders
document.addEventListener("DOMContentLoaded",()=>{
  function ensureBAModal(){
    let modal = document.querySelector(".ba-modal");
    if(modal) return modal;
    modal = document.createElement("div");
    modal.className = "ba-modal";
    modal.innerHTML = `
      <div class="ba-modal-content">
        <button class="img-lightbox-close" aria-label="Close before after viewer">×</button>
        <h3 class="ba-modal-title">Before / After Preview</h3>
        <div class="ba-modal-holder"></div>
        <div class="ba-modal-note">Drag the slider to compare before and after.</div>
      </div>
    `;
    document.body.appendChild(modal);
    const close = ()=> modal.classList.remove("open");
    modal.querySelector(".img-lightbox-close").addEventListener("click", close);
    modal.addEventListener("click", ev => { if(ev.target === modal) close(); });
    document.addEventListener("keydown", ev => { if(ev.key === "Escape") close(); });
    return modal;
  }

  function wireBA(box){
    if(!box) return;
    const range = box.querySelector(".range");
    const after = box.querySelector(".after");
    const line = box.querySelector(".line");
    const handle = box.querySelector(".handle");
    const update = ()=>{
      const value = (range?.value || 50) + "%";
      if(after) after.style.clipPath = `inset(0 0 0 ${value})`;
      if(line) line.style.left = value;
      if(handle) handle.style.left = value;
    };
    if(range){
      range.removeEventListener?.("input", update);
      range.addEventListener("input", update);
      update();
    }
  }

  document.querySelectorAll(".vs-grid .ba").forEach((box, i)=>{
    wireBA(box);

    let btn = box.querySelector(".ba-open");
    if(!btn){
      btn = document.createElement("button");
      btn.type = "button";
      btn.className = "ba-open";
      btn.title = "Open before / after";
      btn.setAttribute("aria-label","Open before after full screen");
      btn.innerHTML = "⛶";
      box.appendChild(btn);
    }

    btn.onclick = (e)=>{
      e.preventDefault();
      e.stopPropagation();
      const modal = ensureBAModal();
      const holder = modal.querySelector(".ba-modal-holder");
      holder.innerHTML = "";

      const clone = box.cloneNode(true);
      const cloneBtn = clone.querySelector(".ba-open");
      if(cloneBtn) cloneBtn.remove();
      holder.appendChild(clone);

      wireBA(clone);

      const title = box.closest(".card")?.querySelector("h3")?.textContent?.trim() || `Before / After ${i+1}`;
      modal.querySelector(".ba-modal-title").textContent = title;
      modal.classList.add("open");
    };
  });
});

if('serviceWorker' in navigator){
  window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
}


// Portfolio category filters
document.addEventListener("DOMContentLoaded",()=>{
  const buttons = document.querySelectorAll(".portfolio-filters button");
  const items = document.querySelectorAll(".mixed-portfolio .item[data-category]");
  if(!buttons.length || !items.length) return;

  buttons.forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const filter = btn.dataset.filter;
      buttons.forEach(b=>b.classList.remove("active"));
      btn.classList.add("active");
      items.forEach(item=>{
        item.classList.toggle("hide", !(filter === "all" || item.dataset.category === filter));
      });
    });
  });
});


document.addEventListener("DOMContentLoaded",()=>{
  const input = document.getElementById("clientFiles");
  const zone = document.getElementById("uploadZone");
  const preview = document.getElementById("filePreview");
  if(!input || !zone || !preview) return;

  const humanSize = bytes => {
    if(bytes < 1024) return bytes + " B";
    if(bytes < 1024*1024) return (bytes/1024).toFixed(1) + " KB";
    return (bytes/(1024*1024)).toFixed(1) + " MB";
  };

  const render = () => {
    preview.innerHTML = "";
    [...input.files].forEach(file=>{
      const row = document.createElement("div");
      row.className = "file-chip";
      row.innerHTML = `<b>${file.name}</b><span>${humanSize(file.size)}</span>`;
      preview.appendChild(row);
    });
  };

  input.addEventListener("change", render);
  ["dragenter","dragover"].forEach(ev=>zone.addEventListener(ev,e=>{
    e.preventDefault();
    zone.classList.add("dragover");
  }));
  ["dragleave","drop"].forEach(ev=>zone.addEventListener(ev,e=>{
    e.preventDefault();
    zone.classList.remove("dragover");
  }));
});


// Before/after compare sliders
document.addEventListener("DOMContentLoaded",()=>{
  document.querySelectorAll(".interactive-compare").forEach((wrap)=>{
    const range = wrap.querySelector(".compare-range");
    const afterWrap = wrap.querySelector(".after-wrap");
    const handle = wrap.querySelector(".compare-handle");
    const update = () => {
      const v = range.value + "%";
      afterWrap.style.width = v;
      handle.style.left = v;
    };
    if(range){
      range.addEventListener("input", update);
      update();
    }
  });
});


// 10 MB

  function totalFileSize(){
    if(!fileInput || !fileInput.files) return 0;
    return [...fileInput.files].reduce((sum, file)=>sum + file.size, 0);
  }

  function humanMB(bytes){
    return (bytes / (1024 * 1024)).toFixed(2) + " MB";
  }

  function validateUpload(){
    if(!fileInput) return true;
    const total = totalFileSize();

    if(total > MAX_TOTAL){
      if(warning){
        warning.className = "upload-warning error";
        warning.textContent =
          "Selected files total " + humanMB(total) +
          ". Direct uploads must stay under 10 MB. Please remove files or use a Drive/Dropbox/WeTransfer link.";
      }
      return false;
    }

    if(warning){
      warning.className = "upload-warning ok";
      warning.textContent = total > 0 ? "Selected files: " + humanMB(total) + " total." : "";
    }
    return true;
  }

  if(fileInput){
    fileInput.addEventListener("change", validateUpload);
  }

  if(form){
    form.addEventListener("submit",(event)=>{
      if(!validateUpload()){
        event.preventDefault();
        if(status){
          status.className = "lead-form-status error";
          status.textContent = "Please reduce the attached file size or use the file-link field.";
        }
        return;
      }

      if(submitBtn){
        submitBtn.disabled = true;
        submitBtn.textContent = "Sending...";
      }
      if(status){
        status.className = "lead-form-status";
        status.textContent = "Submitting your project...";
      }
    });
  }
});




// RealtyPixelWorks lead form — Web3Forms FREE-plan safe
document.addEventListener("DOMContentLoaded",()=>{
  const form = document.getElementById("leadForm");
  const status = document.getElementById("leadFormStatus");
  const submitBtn = document.getElementById("leadSubmitBtn");
  if(!form) return;

  form.addEventListener("submit", async (event)=>{
    event.preventDefault();

    const originalText = submitBtn ? submitBtn.textContent : "Submit Lead";
    if(submitBtn){
      submitBtn.disabled = true;
      submitBtn.textContent = "Sending...";
    }
    if(status){
      status.className = "lead-form-status";
      status.textContent = "Submitting your project...";
    }

    try{
      const formData = new FormData(form);

      const response = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        body: formData,
        headers: { "Accept": "application/json" }
      });

      const data = await response.json();

      if(response.ok && data.success){
        if(status){
          status.className = "lead-form-status success";
          status.textContent = "Lead submitted successfully.";
        }
        form.reset();
        setTimeout(()=>{ window.location.href = "thank-you.html"; }, 600);
      } else {
        throw new Error(data && data.message ? data.message : "Submission failed");
      }
    } catch(error){
      console.error("Web3Forms error:", error);
      if(status){
        status.className = "lead-form-status error";
        status.textContent = "Could not submit right now. Please check the file link and try again.";
      }
    } finally {
      if(submitBtn){
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
      }
    }
  });
});
